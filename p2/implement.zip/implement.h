template<int size>
class ClassWithFixedSize {
public:
    char data[size];
};