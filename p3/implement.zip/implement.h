#include <cmath>

template<class T>
bool Equal(T a, T b) {
    return a == b;
}

template<>
bool Equal(float a, float b) {
    return fabs(a - b) < 1e-3;
}

template<>
bool Equal(double a, double b) {
    return fabs(a - b) < 1e-3;
}

template<>
bool Equal(long double a, long double b) {
    return fabs(a - b) < 1e-3;
}